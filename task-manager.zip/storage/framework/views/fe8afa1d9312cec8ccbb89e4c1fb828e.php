

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
  <div class="col-12 col-md-10 col-lg-8">
    <div class="card shadow-sm">
      <div class="card-body">
        <h3 class="h5 mb-3"><?php echo e(isset($task) ? 'Edit Task' : 'Create Task'); ?></h3>

        <form method="POST" action="<?php echo e(isset($task) ? route('tasks.update', $task) : route('tasks.store')); ?>">
          <?php echo csrf_field(); ?>
          <?php if(isset($task)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

          <div class="mb-3">
            <label class="form-label">Title</label>
            <input name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('title', $task->title ?? '')); ?>" required>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          <div class="mb-3">
            <label class="form-label">Description</label>
            <textarea name="description" rows="4" class="form-control"><?php echo e(old('description', $task->description ?? '')); ?></textarea>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label">Due Date</label>
              <input type="date" name="due_date" class="form-control" value="<?php echo e(old('due_date', isset($task) && $task->due_date ? $task->due_date->format('Y-m-d') : '')); ?>" required>
            </div>
            <div class="col-md-6">
              <label class="form-label">Status</label>
              <select name="status" class="form-select">
                <option value="pending" <?php echo e(old('status', $task->status ?? '') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                <option value="in_progress" <?php echo e(old('status', $task->status ?? '') == 'in_progress' ? 'selected' : ''); ?>>In Progress</option>
                <option value="done" <?php echo e(old('status', $task->status ?? '') == 'done' ? 'selected' : ''); ?>>Done</option>
              </select>
            </div>
          </div>

          <div class="d-flex gap-2">
            <button class="btn btn-primary"><?php echo e(isset($task) ? 'Update' : 'Create'); ?></button>
            <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-outline-secondary">Cancel</a>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/tasks/create.blade.php ENDPATH**/ ?>