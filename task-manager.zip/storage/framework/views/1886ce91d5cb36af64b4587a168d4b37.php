

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-start mb-4">
  <div>
    <h1 class="h4 mb-0">Tasks</h1>
    <div class="text-muted small">Manage tasks — create, edit, delete, and filter.</div>
  </div>
  <div>
    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary">+ New Task</a>
  </div>
</div>


<form method="GET" action="<?php echo e(route('tasks.index')); ?>" class="row g-2 align-items-end mb-3">
  <div class="col-md-4">
    <label class="form-label small">Search</label>
    <input type="text" name="q" value="<?php echo e(old('q', $q ?? '')); ?>" class="form-control" placeholder="Search title or description">
  </div>

  <div class="col-md-3">
    <label class="form-label small">Status</label>
    <select name="status" class="form-select">
      <option value="">All</option>
      <option value="pending" <?php echo e((isset($status) && $status=='pending') ? 'selected' : ''); ?>>Pending</option>
      <option value="in_progress" <?php echo e((isset($status) && $status=='in_progress') ? 'selected' : ''); ?>>In Progress</option>
      <option value="done" <?php echo e((isset($status) && $status=='done') ? 'selected' : ''); ?>>Done</option>
    </select>
  </div>

  <div class="col-md-3">
    <label class="form-label small">Due date</label>
    <input type="date" name="due_date" value="<?php echo e(old('due_date', $due ?? '')); ?>" class="form-control">
  </div>

  <div class="col-md-2 d-grid">
    <div class="d-flex gap-2">
      <button class="btn btn-outline-primary w-100">Filter</button>
      <a href="<?php echo e(route('tasks.index')); ?>" class="btn btn-outline-secondary">Reset</a>
    </div>
  </div>
</form>

<div class="card shadow-sm">
  <div class="card-body p-0">
    <div class="table-responsive">
      <table class="table table-hover mb-0">
        <thead class="table-light">
          <tr>
            <th>Title</th>
            <th style="width:170px">Status</th>
            <th style="width:140px">Due</th>
            <th style="width:150px" class="text-end">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="fw-semibold"><?php echo e($task->title); ?></div>
              <div class="text-muted small"><?php echo e(\Illuminate\Support\Str::limit($task->description, 80)); ?></div>
            </td>

            <td class="align-middle">
              <?php if($task->status === 'done'): ?>
                <span class="badge bg-success">Done</span>
              <?php elseif($task->status === 'in_progress'): ?>
                <span class="badge bg-warning text-dark">In Progress</span>
              <?php else: ?>
                <span class="badge bg-secondary">Pending</span>
              <?php endif; ?>
            </td>

            <td class="text-muted align-middle"><?php echo e(optional($task->due_date)->format('Y-m-d') ?? '-'); ?></td>

            <td class="text-end align-middle">
              <a href="<?php echo e(route('tasks.edit', $task)); ?>" class="btn btn-sm btn-outline-primary me-1">Edit</a>
              <form action="<?php echo e(route('tasks.destroy', $task)); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this task?')">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="4" class="text-center py-5 text-muted">No tasks found.</td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<div class="mt-3 d-flex justify-content-center">
  <?php echo e($tasks->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/tasks/index.blade.php ENDPATH**/ ?>