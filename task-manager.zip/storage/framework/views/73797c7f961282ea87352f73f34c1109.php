<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Task Reminder</title>
</head>
<body>
  <div style="font-family: sans-serif; line-height: 1.6; color: #111;">
    <h2>Reminder: "<?php echo e($task->title); ?>"</h2>

    <p>Hello <?php echo e($user->name); ?>,</p>

    <p>This is a reminder that the following task is due tomorrow (<?php echo e(\Carbon\Carbon::parse($task->due_date)->format('Y-m-d')); ?>):</p>

    <p>
      <strong><?php echo e($task->title); ?></strong><br>
      <?php echo e($task->description ?? 'No description provided.'); ?>

    </p>

    <p>
      <strong>Due:</strong> <?php echo e(\Carbon\Carbon::parse($task->due_date)->format('Y-m-d')); ?><br>
      <strong>Status:</strong> <?php echo e(ucfirst($task->status)); ?>

    </p>

    <p>
      If you’ve already completed this task, you can ignore this reminder.
    </p>

    <p>Thanks,<br/><?php echo e(config('app.name')); ?></p>
  </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\task-manager\resources\views/emails/task_reminder.blade.php ENDPATH**/ ?>