import './bootstrap';
import 'bootstrap';   // add bootstrap js
import '../css/app.css';